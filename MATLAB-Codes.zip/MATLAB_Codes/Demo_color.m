clear; clc; close all force;

% Read the input image 
x = double(imread('monarch.png'));

d = 4; % downscaling factor

[row, col, ch] = size(x);
row_out = row/d;
col_out = col/d;
x_our = zeros(row_out, col_out, ch);

K = 3; % Set a value; recommended default k = d
Lambda = 2;  % tuning parameter

for color = 1:ch
    
r = x(:,:,color);
x_pad = padarray(r, [K, K]);


C_red = zeros(256, 256);
for i = 1:row
    for j = 1:col
        
        A = x_pad(i+K, j+K);
        
        for k = -K:K            
            for l = -K:K
                
                B = x_pad(i+k+K, j+l+K);
                C_red(A+1, B+1) = C_red(A+1, B+1) + 1;
                
            end
        end
    end
end

x_our(:,:, color) = IDCL(r, col_out, row_out, Lambda, C_red);

end 


figure;
subplot(1,2,1); imshow(uint8(x)); title('Input')
subplot(1,2,2); 
imshow(uint8(x_our)); title('Downscaled using IDCL')


